package com.gilberttrianto.asyntaskexample;

public interface MyAsynTaskCallback {
    void onPreExecute();
    void onUpdateProgress(long value);
    void onPostExecute(String text);

}
